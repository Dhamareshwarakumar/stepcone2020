<?php  
$conn = new mysqli("208.91.198.197:3306","stepcone2019","Stepcone@2019");  
mysqli_select_db($conn, 'stepcone2019');  
//$sql = "SELECT Fname,Lname,Year,Department,Registrationnumber,Institutename,Email,Phoneno from registration";
$str=$_GET['link'];
//echo $str;
$sql="select Fname,Lname,Year,Department,Registrationnumber,Institutename,Email,Phoneno from registration".$str." order by Email";
//echo $sql;  
$setRec = mysqli_query($conn, $sql);  
$columnHeader = '';  
$columnHeader =  "First Name" . "\t" . "Last Name" . "\t" . "Year" . "\t" . "Department" . "\t" . "Reg no" . "\t" . "College" . "\t"  . "Email" . "\t" . "Phone no" . "\t" ;  
$setData = '';  
  while ($rec = mysqli_fetch_row($setRec)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=User_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";  
 ?> 
 