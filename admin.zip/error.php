<?php
echo "<center>**************************YOU ARE NOT ALLOWED TO ACCESS THIS PAGE********************************</center>";

?>